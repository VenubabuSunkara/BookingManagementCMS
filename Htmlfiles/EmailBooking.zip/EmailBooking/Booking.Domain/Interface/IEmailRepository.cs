﻿using Booking.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Booking.Domain.Interfaces
{
    public interface IEmailRepository
    {
        public Task<EmailTableEntity> GetEmailQueue(string SearchValue, int Take, int Skip, CancellationToken token);
    }
}
