﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Booking.Domain.Entities
{

    public class EmailTableEntity
    {
        public int TotalRecords { get; set; }
        public int FilterRecords { get; set; }
        public List<EmailQueueEntity>? EmailEntities { get; set; }
    }
    public class EmailQueueEntity
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? EmailSubject { get; set; }
        public string? EmailBody { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime UpdatedOn { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
        public bool IsEnabled { get; set; }
        public string? SenderEmail { get; set; }
    }
}
