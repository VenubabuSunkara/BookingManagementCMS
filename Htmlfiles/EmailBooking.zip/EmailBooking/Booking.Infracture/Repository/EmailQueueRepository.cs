﻿using Amazon.Runtime.Internal.Util;
using Booking.Domain.Entities;
using Booking.Domain.Interfaces;
using Booking.Infrastructure.Data;
using Booking.Infrastructure.Data.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json.Linq;
using System.Buffers;

namespace Booking.Infrastructure.Repositories
{
    public class EmailQueueRepository(BookingCmsContext context, IMemoryCache cache) : IEmailRepository
    {
        private readonly BookingCmsContext _context = context;
        private readonly IMemoryCache _cache = cache;
        public async Task<EmailTableEntity> GetEmailQueue(string SearchValue, int Take, int Skip, CancellationToken token)
        {
            var q = _context.EmailTemplates.AsNoTracking();
            var total = await q.CountAsync(token);

            if (!string.IsNullOrWhiteSpace(SearchValue))
            {
                q = q.Where(d => d.Id.ToString() == SearchValue);
            }
            // simple order by FullName default
            q = q.OrderByDescending(d => d.CreatedOn);

            var filtered = await q.CountAsync(token);
            var page = await q.Skip(Skip).Take(Take).ToListAsync(token);

            var response = new EmailTableEntity
            {
                TotalRecords = total,
                FilterRecords = filtered,
                EmailEntities = [.. page.Select(d => new EmailQueueEntity
                {
                    Id = d.Id,
                    Name = d.Name,
                    EmailSubject = d.EmailSubject,
                    EmailBody = d.EmailBody,
                    CreatedOn = d.CreatedOn,
                    UpdatedOn = d.UpdatedOn,
                    CreatedBy = d.CreatedBy,
                    UpdatedBy = d.UpdatedBy,
                    IsEnabled = d.IsEnabled,
                    SenderEmail = d.SenderEmail
                })]
            };
            return response;
        }
    }
}
