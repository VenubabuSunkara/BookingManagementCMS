﻿using Booking.Domain.Entities;
using Booking.Domain.Interfaces;
using Booking.Web.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Net.Mail;
using System.Configuration;

namespace Booking.Web.Controllers
{
    public class EmailQueueController : BaseController
    {
        private readonly IEmailRepository _emailRepository;
        public EmailQueueController(IEmailRepository emailRepository) 
        {
            _emailRepository = emailRepository;
        }

        public async Task<IActionResult> Index(CancellationToken token)
        {
            return await Task.Run(() =>
            {
                return View();
            }, token);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> LoadEmailQueueData([FromBody] DataTableAjaxPostModel request, CancellationToken token)
        {
            try
            {
                string search = "";
                if (!String.IsNullOrEmpty(request.search?.value))
                    search = request.search?.value ?? string.Empty;
                var result = await _emailRepository.GetEmailQueue(search, request.length, request.start, token);
                var response = result.EmailEntities.Select(x => new {
                    x.Id,
                    x.Name, 
                    x.EmailSubject, 
                    x.EmailBody,      
                    x.CreatedOn,
                    x.UpdatedOn,
                    x.CreatedBy,
                    x.UpdatedBy,
                    x.IsEnabled,
                    x.SenderEmail
                });
                return Json(new
                {
                    draw = request.draw == 0 ? 1 : request.draw,
                    recordsFiltered = result.FilterRecords,
                    recordsTotal = result.TotalRecords,
                    data = response.ToList()
                });
            }
            catch (Exception ex)
            {
                return Json("Something went wrong {0}", ex);
            }
        }

        [HttpPost]
        public IActionResult SendMail([FromBody] EmailQueueEntity model)
        {
            if (model == null)
            {
                return Json(new { success = false, message = "Invalid data" });
            }
            var subject = model.EmailSubject;
            var body = model.EmailBody;
            var recipient = model.SenderEmail;
            try
            {
                // SMTP client setup
                using (var smtp = new SmtpClient("smtp.gmail.com", 587))
                {
                    smtp.Credentials = new NetworkCredential("skafrid545@gmail.com", "mjwuvlxytqhlrnrn");
                    smtp.EnableSsl = true; // true if SSL required

                    // Construct the mail
                    var mail = new MailMessage
                    {
                        From = new MailAddress("skafrid545@gmail.com"),
                        Subject = model.EmailSubject,
                        Body = model.EmailBody,
                        IsBodyHtml = true
                    };

                    mail.To.Add(model.SenderEmail);

                    // Send the mail
                    smtp.Send(mail);
                }
                return Json(new { success = true, message = "Mail sent successfully!" });
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
